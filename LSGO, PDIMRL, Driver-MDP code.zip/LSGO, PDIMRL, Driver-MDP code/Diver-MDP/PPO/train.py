import os
import glob
import time
from datetime import datetime

import torch
import numpy as np
import matplotlib.pyplot as plt_
from matplotlib.gridspec import GridSpec
import pandas as pd
import time
import gym

from PPO import PPO


################################### Training ###################################
def train():
    print("============================================================================================")

    ####### initialize environment hyperparameters ######
    env_name = "Train-v2"

    has_continuous_action_space = True  # continuous action space; else discrete

    max_ep_len = 13  # max timesteps in one episode
    max_training_timesteps = int(3e6)  # break training loop if timeteps > max_training_timesteps

    print_freq = max_ep_len * 20  # print avg reward in the interval (in num timesteps)
    log_freq = max_ep_len * 2  # log avg reward in the interval (in num timesteps)
    save_model_freq = int(1e5)  # save model frequency (in num timesteps)

    action_std = 0.1  # starting std for action distribution (Multivariate Normal)
    action_std_decay_rate = 0.02  # linearly decay action_std (action_std = action_std - action_std_decay_rate)
    min_action_std = 0.01  # minimum action_std (stop decay after action_std <= min_action_std)
    action_std_decay_freq = int(1e4)  # action_std decay frequency (in num timesteps)
    #####################################################

    ## Note : print/log frequencies should be > than max_ep_len

    ################ PPO hyperparameters ################
    update_timestep = max_ep_len * 4  # update policy every n timesteps
    K_epochs = 2  # update policy for K epochs in one PPO update

    eps_clip = 0.2  # clip parameter for PPO
    gamma = 0.99  # discount factor

    lr_actor = 0.0003  # learning rate for actor network
    lr_critic = 0.001  # learning rate for critic network

    random_seed = 0  # set random seed if required (0 = no random seed)
    #####################################################

    print("training environment name : " + env_name)

    env = gym.make(env_name)

    # state space dimension
    state_dim = env.observation_space.shape[0]

    # action space dimension
    if has_continuous_action_space:
        action_dim = env.action_space.shape[0]
    else:
        action_dim = env.action_space.n

    ###################### logging ######################

    #### log files for multiple runs are NOT overwritten
    log_dir = "PPO_logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    log_dir = log_dir + '/' + env_name + '/'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    #### get number of log files in log directory
    run_num = 0
    current_num_files = next(os.walk(log_dir))[2]
    run_num = len(current_num_files)

    #### create new log file for each run
    log_f_name = log_dir + '/PPO_' + env_name + "_log_" + str(run_num) + ".csv"

    print("current logging run number for " + env_name + " : ", run_num)
    print("logging at : " + log_f_name)
    #####################################################

    ################### checkpointing ###################
    run_num_pretrained = 0  #### change this to prevent overwriting weights in same env_name folder

    directory = "PPO_preTrained"
    if not os.path.exists(directory):
        os.makedirs(directory)

    directory = directory + '/' + env_name + '/'
    if not os.path.exists(directory):
        os.makedirs(directory)

    checkpoint_path = directory + "PPO_{}_{}_{}.pth".format(env_name, random_seed, run_num_pretrained)
    print("save checkpoint path : " + checkpoint_path)
    #####################################################

    ############# print all hyperparameters #############
    print("--------------------------------------------------------------------------------------------")
    print("max training timesteps : ", max_training_timesteps)
    print("max timesteps per episode : ", max_ep_len)
    print("model saving frequency : " + str(save_model_freq) + " timesteps")
    print("log frequency : " + str(log_freq) + " timesteps")
    print("printing average reward over episodes in last : " + str(print_freq) + " timesteps")
    print("--------------------------------------------------------------------------------------------")
    print("state space dimension : ", state_dim)
    print("action space dimension : ", action_dim)
    print("--------------------------------------------------------------------------------------------")
    if has_continuous_action_space:
        print("Initializing a continuous action space policy")
        print("--------------------------------------------------------------------------------------------")
        print("starting std of action distribution : ", action_std)
        print("decay rate of std of action distribution : ", action_std_decay_rate)
        print("minimum std of action distribution : ", min_action_std)
        print("decay frequency of std of action distribution : " + str(action_std_decay_freq) + " timesteps")
    else:
        print("Initializing a discrete action space policy")
    print("--------------------------------------------------------------------------------------------")
    print("PPO update frequency : " + str(update_timestep) + " timesteps")
    print("PPO K epochs : ", K_epochs)
    print("PPO epsilon clip : ", eps_clip)
    print("discount factor (gamma) : ", gamma)
    print("--------------------------------------------------------------------------------------------")
    print("optimizer learning rate actor : ", lr_actor)
    print("optimizer learning rate critic : ", lr_critic)
    if random_seed:
        print("--------------------------------------------------------------------------------------------")
        print("setting random seed to ", random_seed)
        torch.manual_seed(random_seed)
        env.seed(random_seed)
        np.random.seed(random_seed)
    #####################################################

    print("============================================================================================")

    ################# training procedure ################

    # initialize a PPO agent
    ppo_agent = PPO(state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip, has_continuous_action_space,
                    action_std)

    # track total training time
    start_time = datetime.now().replace(microsecond=0)
    print("Started training at (GMT) : ", start_time)

    print("============================================================================================")

    # logging file
    log_f = open(log_f_name, "w+")
    log_f.write('episode,timestep,reward\n')

    # printing and logging variables
    print_running_reward = 0
    print_done_reward = 0
    print_running_episodes = 0

    log_running_reward = 0
    log_running_episodes = 0

    time_step = 0
    i_episode = 0

    energy = []
    t_error = []
    jerk = []

    e_r = []
    t_r = []
    j_r = []
    all_R = []

    e_thr = []

    r_action_std = []

    plt_.ion()  # 开启交互模式
    fig = plt_.figure(figsize=(8, 5))
    gs = GridSpec(5, 2, figure=fig, width_ratios=[10, 5], height_ratios=[4, 1, 4, 1, 4])
    ax_reward = fig.add_subplot(gs[0:5, 0])
    ax_energy = fig.add_subplot(gs[0, 1])
    ax_t_error = fig.add_subplot(gs[2, 1])
    ax_jerk = fig.add_subplot(gs[4, 1])

    ax_reward.set_title('Reward')
    ax_energy.set_title('Energy')
    ax_t_error.set_title('T Error')
    ax_jerk.set_title('Action Std')

    ax_reward.grid()
    ax_energy.grid()
    ax_t_error.grid()
    ax_jerk.grid()

    energy_out = []
    t_errror_out = []

    line_all_R, = ax_reward.plot(all_R, label='all_reward')
    line_e_r, = ax_reward.plot(e_r, label='E_reward')
    line_t_r, = ax_reward.plot(t_r, label='T_reward')
    line_j_r, = ax_reward.plot(j_r, label='J_reward')

    line_e_thr, = ax_energy.plot(e_thr, label='E_thr')
    line_energy, = ax_energy.plot(energy, label='energy')

    line_t_error, = ax_t_error.plot(t_error, label='t_error')

    # line_jerk, = ax_jerk.plot(jerk, label='jerk')
    line_std, = ax_jerk.plot(r_action_std, label='action_std')

    reward_mean = 0
    is_first = True
    epoach = 0
    # training loop
    while time_step <= max_training_timesteps:

        state = env.reset()
        current_ep_reward = 0
        current_ep_done_reward = 0

        for t in range(1, max_ep_len + 1):

            # select action with policy
            action = ppo_agent.select_action(state)
            for i in range(len(action)):
                action[i] = min(max(action[i], 0), 1)

            state, reward, done, _, info = env.step(action)


            if info[0] < info[6] / 1.04 and info[1] < 2:
                energy_out.append(info[0])
                t_errror_out.append(info[1])
                print('Good', len(energy_out), '  energy:', info[0], '  t error:', info[1])

            if len(all_R) % 50 == 0 and len(all_R) != 0:
                # save all done rewards to Excel
                done_rewards = pd.DataFrame({'done_rewards': all_R})
                done_rewards.to_excel('2_.xlsx', index=False)

            if done:
                epoach += 1
                if epoach % 50 == 0:
                    pass

                if is_first:
                    reward_mean = max(reward, -30)
                    is_first = False
                else:
                    reward_mean = reward_mean * 0.99 + max(reward, -30) * 0.01

                reward_action_std = min(max(0.001, 1 * action_std * max((6 - reward_mean) / 24, 0)), 0.5)
                ppo_agent.set_action_std(reward_action_std)

                r_action_std.append(reward_action_std)

                energy.append(info[0])
                t_error.append(info[1])
                jerk.append(info[2])
                e_r.append(info[3])
                t_r.append(info[4])
                j_r.append(info[5])
                all_R.append(reward)
                e_thr.append(info[6] / 1.05)



                line_all_R.set_ydata(all_R[-2000:])
                line_all_R.set_xdata(range(len(all_R[-2000:])))
                line_e_r.set_ydata(e_r[-2000:])
                line_e_r.set_xdata(range(len(all_R[-2000:])))
                line_t_r.set_ydata(t_r[-2000:])
                line_t_r.set_xdata(range(len(all_R[-2000:])))
                line_j_r.set_ydata(j_r[-2000:])
                line_j_r.set_xdata(range(len(all_R[-2000:])))

                line_e_thr.set_ydata(e_thr[-2000:])
                line_e_thr.set_xdata(range(len(all_R[-2000:])))
                line_energy.set_ydata(energy[-2000:])
                line_energy.set_xdata(range(len(all_R[-2000:])))

                line_t_error.set_ydata(t_error[-2000:])
                line_t_error.set_xdata(range(len(all_R[-2000:])))

                line_std.set_ydata(r_action_std[-2000:])
                line_std.set_xdata(range(len(all_R[-2000:])))

                ax_reward.relim()
                ax_reward.autoscale_view()
                ax_energy.relim()
                ax_energy.autoscale_view()
                ax_t_error.relim()
                ax_t_error.autoscale_view()
                ax_jerk.relim()
                ax_jerk.autoscale_view()

                ax_reward.legend()
                ax_energy.legend()
                ax_t_error.legend()
                ax_jerk.legend()
                fig.canvas.manager.set_window_title("Experiment 2")
                plt_.draw()
                plt_.pause(0.00000000001)
            # saving reward and is_terminals
            #ppo_agent.buffer.rewards.append(reward)
            #ppo_agent.buffer.is_terminals.append(done)

            if 'temp_reward' not in locals():
                temp_reward = []
            if not done:
                temp_reward.append(reward)
            if done:
                avg = reward / len(temp_reward)*10
                temp_reward = [r + avg for r in temp_reward]
                for r in temp_reward:
                    ppo_agent.buffer.rewards.append(r)
                    ppo_agent.buffer.is_terminals.append(False)
                ppo_agent.buffer.is_terminals.append(True)
                ppo_agent.buffer.rewards.append(reward)
                temp_reward = []


            time_step += 1
            current_ep_reward += reward
            if done:
                current_ep_done_reward += reward
            # update PPO agent
            if time_step % update_timestep == 0:
                ppo_agent.update()

            '''
            # if continuous action space; then decay action std of ouput action distribution
            if has_continuous_action_space and time_step % action_std_decay_freq == 0:
                ppo_agent.decay_action_std(action_std_decay_rate, min_action_std)
            '''
            # log in logging file
            if time_step % log_freq == 0:
                # log average reward till last episode
                log_avg_reward = log_running_reward / log_running_episodes
                log_avg_reward = round(log_avg_reward, 4)

                log_f.write('{},{},{}\n'.format(i_episode, time_step, log_avg_reward))
                log_f.flush()

                log_running_reward = 0
                log_running_episodes = 0

            # printing average reward
            if time_step % print_freq == 0:
                # print average reward till last episode
                print_avg_reward = print_running_reward / print_running_episodes
                print_avg_reward = round(print_avg_reward, 2)
                print_done_reward = print_done_reward / print_running_episodes
                print_done_reward = round(print_done_reward, 2)
                print("Episode : {} \t\t Timestep : {} \t\t Average Reward : {} \t\t Done Reward : {}".format(i_episode, time_step,
                                                                                                              print_avg_reward, print_done_reward))
                print_done_reward = 0
                print_running_reward = 0
                print_running_episodes = 0

            # save model weights
            if time_step % save_model_freq == 0:
                print("--------------------------------------------------------------------------------------------")
                print("saving model at : " + checkpoint_path)
                ppo_agent.save(checkpoint_path)
                print("model saved")
                print("Elapsed Time  : ", datetime.now().replace(microsecond=0) - start_time)
                print("--------------------------------------------------------------------------------------------")

            # break; if the episode is over
            if done:
                break
        print_done_reward += current_ep_done_reward
        print_running_reward += current_ep_reward
        print_running_episodes += 1


        log_running_reward += current_ep_reward
        log_running_episodes += 1

        i_episode += 1

    log_f.close()
    env.close()

    # print total training time
    print("============================================================================================")
    end_time = datetime.now().replace(microsecond=0)
    print("Started training at (GMT) : ", start_time)
    print("Finished training at (GMT) : ", end_time)
    print("Total training time  : ", end_time - start_time)
    print("============================================================================================")


if __name__ == '__main__':
    train()







