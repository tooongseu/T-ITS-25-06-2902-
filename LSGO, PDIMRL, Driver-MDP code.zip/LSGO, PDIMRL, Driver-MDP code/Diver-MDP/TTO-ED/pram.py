slope = [0, 3, -8, 3, 10, 0, 0]
slope_seg = [0, 1520, 6200, 12310, 19090, 35100, 46110]
speed_lim = [80.0, 300.0, 250, 300, 280, 0]
speed_lim_seg = [0, 1000, 18000, 19500, 33000, 46110]
line_len = slope_seg[-1]

plan_time = 1000
train_type = 8
train_section_len = 25.375
train_len = 203
train_power = 8760
train_weight = 490
train_mass_factor = 1.03
train_max_traction = 310.72
max_action = 1
min_action = 0
max_braking = -1
max_traction = 0.5

drag_coefficient_a = 0.26
drag_coefficient_b = 0.0046
drag_coefficient_c = 0.000122

reward_c = 5
reward_x = 1
train_step = 1
step = 50
wave = 0.05
fsb_scale = 0.6
max_speed = 75
screen_width = 700
screen_height = 650
x_zoom = screen_width / (line_len+1)
y_zoom = screen_height / (max(speed_lim))

def pram():
    pass