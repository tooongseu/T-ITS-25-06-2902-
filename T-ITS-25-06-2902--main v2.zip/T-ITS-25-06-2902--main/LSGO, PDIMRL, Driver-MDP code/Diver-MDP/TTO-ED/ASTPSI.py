import copy

import pram
import sys
from gym.envs.tong.TTO import tong_utils as utils
sys.path.append('/opt/miniconda3/envs/CJU/lib/python3.8/site-packages/gym/envs/tong/TTO/')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def smple():
    mri, min_t, min_seg_t, v_frontier = utils.get_mri()

    ast_seg_t, _ = allocation_surplus_time(min_t, copy.deepcopy(min_seg_t))

    max_rate = min((1.644752306055271 + 1) / 2, 1.644752306055271)

    t = []

    rates = np.linspace(1, max_rate, 7)

    print(rates)
    psi_a, max_rate = utils.get_psi_part_a(mri, ast_seg_t, copy.deepcopy(min_seg_t), v_frontier)
    min_energy, min_energy_rate = utils.get_psi_min_energy(psi_a, mri, v_frontier, ast_seg_t, max_rate)

    psi, _ = utils.get_psi_part_b(psi_a, mri, v_frontier, ast_seg_t, 1.02)
    psi = np.array(psi) * 3.6
    t.append(psi)

    for i in range(7):
        psi, _ = utils.get_psi_part_b(psi_a, mri, v_frontier, ast_seg_t, rates[i])
        psi = np.array(psi) * 3.6
        t.append(psi)

    upper_bound_psi, lower_bound_psi = utils.get_bessel_curve(psi_a, mri, v_frontier, ast_seg_t, max_rate,
                                                              min_energy_rate)
    speed_limit = utils.get_list(pram.speed_lim, pram.speed_lim_seg, pram.line_len)
    speed_limit = np.array(speed_limit)
    index = np.arange(0, 46111, 1)

    fig = plt.figure(figsize=(5.5, 3.5))
    ax1 = fig.add_subplot()
    ax1.grid(True)
    plt.rcParams.update({'font.size': 8})
    ax1.plot(index, t[0], linewidth=1, color='black')
    ax1.plot(index, t[1], linewidth=1, color='black')
    ax1.plot(index, t[2], linewidth=1, color='black')
    ax1.plot(index, t[3], linewidth=1, color='black')
    ax1.plot(index, t[4], linewidth=1, color='black')
    ax1.plot(index, t[5], linewidth=1, color='black')
    ax1.plot(index, t[6], linewidth=1, color='black')
    ax1.plot(index, t[7], linewidth=1, color='black')
    ax1.plot(index, upper_bound_psi * 3.6, linewidth=1.5)
    ax1.plot(index, lower_bound_psi * 3.6, linewidth=1.5)
    ax1.plot(index, speed_limit, linewidth=1)

    plt.show()


def use():
    mri, min_t, min_seg_t, v_frontier = utils.get_mri()
    ast_seg_t, _ = allocation_surplus_time(min_t, copy.deepcopy(min_seg_t))
    psi_a, max_rate = utils.get_psi_part_a(mri, ast_seg_t, min_seg_t, v_frontier)
    psi_b = utils.get_psi_part_b(psi_a, mri, v_frontier, ast_seg_t, max_rate)
    min_energy_psi, upper_bound_psi, lower_bound_psi, min_energy, min_energy_action, min_energy_times, min_energy_step = planing_speed_interval(mri, min_seg_t, ast_seg_t, v_frontier)
    step_time = utils.get_line_step_time(min_energy_psi)
    me_seg_t = []

    for i in range(1, len(pram.speed_lim_seg)):
        me_seg_t.append(step_time[pram.speed_lim_seg[i]] - step_time[pram.speed_lim_seg[i - 1]])

    print(me_seg_t)
    print(ast_seg_t)
    print(min_seg_t)
    return min_energy_psi, upper_bound_psi, lower_bound_psi, min_energy, min_energy_action, min_energy_times, min_energy_step

def allocation_surplus_time(min_time, seg_times):
    point = pram.speed_lim_seg
    p_time = pram.plan_time
    seg_lens = utils.get_length(point)
    ts_time = p_time - min_time
    if ts_time < 0:
        raise Exception(f"计划时间{p_time:.2f}小于最短运行时间{min_time:.2f}", )
    print("最短时间 计划时间 富余时间")
    print(f"{min_time:.2f},{p_time:.2f},{ts_time:.2f}")

    while True:
        avg_vs = utils.get_avg_v(seg_lens, seg_times)
        seg, v_sort = utils.get_v_sort(avg_vs)
        block = utils.get_block(seg, v_sort)
        block_sum_len = utils.get_block_sum_len(block, seg_lens)
        block_avg_v = utils.get_block_avg_v(block, avg_vs)
        block_len = utils.get_block_len(block, seg_lens)

        delta_rs_time = 1 / block_avg_v[1] - 1 / block_avg_v[0]
        rs_time = delta_rs_time * float(block_sum_len[0])
        if ts_time < rs_time:
            rs_time = ts_time
        ts_time -= rs_time

        seg_times = utils.allocate_runtime(seg_times, block, block_len, block_sum_len, rs_time)
        avg_vs = utils.get_avg_v(seg_lens, seg_times)
        if ts_time == 0:
            break

    return seg_times, avg_vs


def planing_speed_interval(mri, min_seg_t, sat_seg_t, v_frontier):
    psi_a, max_rate = utils.get_psi_part_a(mri, sat_seg_t, min_seg_t, v_frontier)
    min_energy, min_energy_rate = utils.get_psi_min_energy(psi_a, mri, v_frontier, sat_seg_t, max_rate)
    min_energy_psi, _ = utils.get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, min_energy_rate)
    min_energy_action = utils.get_line_action(min_energy_psi)
    min_energy_times = utils.get_line_step_time(min_energy_psi)
    min_energy_step = utils.get_line_step_energy(min_energy_psi)
    on_time_max_mate = utils.get_on_time_max_rate(psi_a, mri, v_frontier, sat_seg_t, max_rate)
    max_rate = min((on_time_max_mate+min_energy_rate)/2, max_rate)

    upper_bound_psi, lower_bound_psi = utils.get_bessel_curve(psi_a, mri, v_frontier, sat_seg_t, max_rate, min_energy_rate)

    return min_energy_psi, upper_bound_psi, lower_bound_psi, min_energy, min_energy_action, min_energy_times, min_energy_step


if __name__ == '__main__':
    use()
