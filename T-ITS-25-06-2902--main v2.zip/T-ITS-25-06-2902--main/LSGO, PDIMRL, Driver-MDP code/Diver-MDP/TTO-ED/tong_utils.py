import numpy as np
from gym.envs.tong.TTO import pram
import copy
import math
from collections import defaultdict
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d


def get_list(info, start_end, line_len):

    output_list = [0]
    point = 0
    present_end = start_end[point + 1]
    present = info[point]

    for location in range(1, line_len + 1):
        if location <= present_end:
            output_list.append(present)
        elif location > present_end:
            if point == len(start_end) - 1:
                present = info[point]
                output_list.append(present)
                break
            point += 1
            present_end = start_end[point + 1]
            present = info[point]
            output_list.append(present)

    return output_list


def get_remain_step(start_end):

    output_list = [start_end[1]]
    for grs_i in range(len(start_end) - 1):
        for remain_step in range(start_end[grs_i + 1] - start_end[grs_i] - 1, -1, -1):
            output_list.append(remain_step)
    return output_list



def get_next_info(start_end, info):

    output = np.zeros(pram.line_len + 1)
    point = 1
    for l in range(1, pram.line_len + 1):
        if l > start_end[point]:
            point += 1
        output[l] = info[point]
    return output


def get_now_info(start_end, info):

    output = np.zeros(pram.line_len + 1)
    point = 1
    for l in range(1, pram.line_len + 1):
        if l > start_end[point]:
            point += 1
        output[l] = info[point - 1]
    output[-1] = 0
    return output


def get_energy(gear_accelerated):

    if gear_accelerated < 0:
        fa = 0
    else:
        fa = math.fabs(gear_accelerated * pram.train_weight * pram.train_step)/3600
    action_energy = fa
    return action_energy



def get_slope_accelerated(location):

    slope_accelerated = 0.0
    G = 9.81
    for section in range(len(pram.slope_seg)):
        if pram.slope_seg[section] < location & location <= pram.slope_seg[section + 1]:
            if location <= pram.train_len + pram.slope_seg[section]:
                if section == 0:
                    slope_accelerated = (pram.slope[section] * G * location) / (pram.train_len * 1000)
                    break
                else:
                    slope_accelerated = (pram.slope[section] * G * (location - pram.slope_seg[section])) / (
                            pram.train_len * 1000) \
                                        + (pram.slope[section - 1] * G * (pram.train_len + pram.slope_seg[section] - location)) / (
                                                pram.train_len * 1000)
                    break
            if location > pram.train_len + pram.slope_seg[section]:
                slope_accelerated = pram.slope[section] * G / 1000

                break

    return slope_accelerated


def get_accelerated(last_speed, gear_accelerated, slope_accelerated, loc):

    G = 9.81
    if loc == 1:
        return gear_accelerated - slope_accelerated
    else:
        basic_acc = (pram.drag_coefficient_a + pram.drag_coefficient_b * last_speed * 3.6 + pram.drag_coefficient_c * (last_speed * 3.6)**2)/pram.train_weight
        return gear_accelerated - slope_accelerated - basic_acc


def get_basic_accelerated(last_speed, loc):

    G = 9.81
    if loc == 1:
        return 0
    else:
        return (pram.drag_coefficient_a + pram.drag_coefficient_b * last_speed * 3.6 + pram.drag_coefficient_c * last_speed * 3.6 * last_speed * 3.6) * G / 1000


def get_speed(last_speed, accelerated, loc):

    if loc == 1:
        return math.sqrt(math.fabs(last_speed * last_speed + 2 * accelerated))
    else:
        if last_speed * last_speed + 2 * accelerated >= 0:
            speed = math.sqrt(math.fabs(last_speed * last_speed + 2 * accelerated))
        else:
            speed = 0
    return speed



def get_move_time(speed, last_speed, accelerated):

    if last_speed != speed:
        time = math.fabs((speed - last_speed) / accelerated)
    else:
        time = math.fabs(pram.train_step / speed)
    return time


def get_py_draw_line(x, y, x_rate=0.5, y_rate=0.5, x_shift=0.25, y_shift=0.25):

    if not isinstance(x, np.ndarray):
        x = np.array(x)
    if not isinstance(y, np.ndarray):
        y = np.array(y)
    speed_limit_xs = x * pram.x_zoom
    speed_limit_ys = y * pram.y_zoom
    speed_limit_xys = \
        list(zip((speed_limit_xs * x_rate + pram.screen_width * x_shift),
                 (speed_limit_ys * y_rate + pram.screen_height * y_shift)))
    return speed_limit_xys


def get_height():

    height = [0]
    for slope_i in range(len(pram.slope) - 1):
        height.append(round(pram.slope[slope_i] + height[slope_i], 3))
    height_y = [0]
    for height_i in range(len(height) - 1):
        space = int(float(pram.slope_seg[height_i + 1] - pram.slope_seg[height_i]))
        start = float(height[height_i])
        end = float(height[height_i + 1])
        temp = np.linspace(start, end, space)
        height_y = np.concatenate((height_y, temp))
    return height_y


def get_length(point):

    length = []
    for p_i in range(len(point) - 1):
        length.append(point[p_i + 1] - point[p_i])
    return length


def get_avg_v(len_seg, time_seg):

    avg_v = []
    for len_i, time_i in zip(len_seg, time_seg):
        avg_v.append(len_i / time_i)
    return avg_v


def get_v_sort(avg_v):

    seg = np.arange(0, len(avg_v), 1)
    v_sort = copy.deepcopy(avg_v)

    for i in range(len(seg)):
        for j in range(0, len(seg) - i - 1):
            if v_sort[j] < v_sort[j + 1]:
                v_sort[j], v_sort[j + 1] = v_sort[j + 1], v_sort[j]
                seg[j], seg[j + 1] = seg[j + 1], seg[j]

    for i in range(len(v_sort)-1):
        if v_sort[i] != v_sort[i+1] and math.fabs(v_sort[i+1] - v_sort[i]) <= 0.0000000001:
            v_sort[i+1] = v_sort[i]
    return seg, v_sort


def get_block(seg, v_sort):


    groups = defaultdict(list)
    for i in range(len(v_sort)):
        groups[v_sort[i]].append(seg[i])
    block = []
    for key in sorted(groups.keys(), reverse=True):
        block.append(groups[key])
    return block


def get_block_sum_len(block, seg_len):

    block_sum_len = []
    for group in block:
        group_sum = 0
        for bsl_index in group:
            group_sum += seg_len[bsl_index]
        block_sum_len.append(group_sum)
    return block_sum_len


def get_block_len(block, seg_len):

    block_len = []
    for group in block:
        group_values = []
        for bl_index in group:
            group_values.append(seg_len[bl_index])
        block_len.append(group_values)
    return block_len


def get_block_avg_v(block, avg_v):

    block_avg_v = []
    for i in range(len(block)):
        block_avg_v.append(avg_v[block[i][0]])
    return block_avg_v


def allocate_runtime(seg_time, block, block_len, block_sum_len, rs_time):

    first_block = block[0]
    first_block_len = block_len[0]
    first_block_sum_len = block_sum_len[0]
    for i in range(len(first_block)):
        seg_index = first_block[i]
        seg_length = first_block_len[i]
        allocated_time = (seg_length / first_block_sum_len) * rs_time
        seg_time[seg_index] += allocated_time
    return seg_time


def get_mri():

    v = np.array([np.zeros(pram.line_len + 1), np.zeros(pram.line_len + 1)])
    v_frontier = np.array([pram.speed_lim_seg, pram.speed_lim_seg])
    v_lim = get_now_info(pram.speed_lim_seg, pram.speed_lim)

    seg = 1
    loc = 0
    while True:
        loc += 1
        if v[0][loc - 1] == 0:
            max_gear_action = pram.max_traction
        else:
            max_gear_action = min(pram.max_traction, pram.train_power / (pram.train_mass_factor * pram.train_weight * v[0][loc - 1]))

        gear_acc = max_gear_action
        slope_acc = get_slope_accelerated(loc)
        last_v = v[0][loc - 1]
        acc = get_accelerated(last_v, gear_acc, slope_acc, loc)
        now_v = min(v_lim[loc] / 3.6, math.sqrt(last_v ** 2 + 2 * acc * pram.train_step))
        v[0][loc] = now_v
        if now_v == v_lim[loc] / 3.6:
            for i in range(len(pram.speed_lim_seg)):
                if pram.speed_lim_seg[i] < loc <= pram.speed_lim_seg[i + 1]:
                    v_frontier[0][seg] = loc
                    loc = pram.speed_lim_seg[i + 1]
                    if loc != pram.speed_lim_seg[-2]:
                        v[0][loc] = min(now_v, v_lim[loc + 1] / 3.6)
                    seg += 1
                    break
        if loc == pram.speed_lim_seg[seg]:
            seg += 1
        if loc == pram.speed_lim_seg[-2]:
            break

    seg = -2
    loc = pram.line_len + 1
    while True:
        loc -= 1
        gear_acc = pram.max_braking
        slope_acc = get_slope_accelerated(loc - 1)
        # now_v**2-last_v**2 = 2(gear_acc-slope_acc-basic_acc)train_step
        # basic_acc = a + b*last_v*3.6 + c*(last_v*3.6)**2
        now_v = v[1][loc]
        if now_v != v_lim[loc - 1] / 3.6:
            a = 1 - 2 * pram.train_step * pram.drag_coefficient_c * 3.6 ** 2 * (9.81 / 1000)
            b = -2 * pram.train_step * pram.drag_coefficient_b * 3.6 * (9.81 / 1000)
            c = -now_v ** 2 + 2 * pram.train_step * (gear_acc - slope_acc - pram.drag_coefficient_a * (9.81 / 1000))
            last_v = min(v_lim[loc - 1] / 3.6, (-b + math.sqrt(b ** 2 - 4 * a * c)) / (2 * a))
        else:
            last_v = v_lim[loc - 1] / 3.6
        v[1][loc - 1] = last_v
        if last_v == v_lim[loc] / 3.6:
            for i in range(len(pram.speed_lim_seg)):
                if pram.speed_lim_seg[i] < loc <= pram.speed_lim_seg[i + 1]:
                    v_frontier[1][seg] = loc
                    loc = pram.speed_lim_seg[i] + 1
                    if loc != pram.speed_lim_seg[1] + 1:
                        v[1][loc - 1] = last_v
                    seg -= 1
                    break
        if loc == pram.speed_lim_seg[seg]:
            seg -= 1
        if loc == pram.speed_lim_seg[1] + 1:
            break

    for i in range(1, len(pram.speed_lim_seg) - 1):
        if v_frontier[0][i] >= v_frontier[1][i]:
            for j in range(pram.speed_lim_seg[i], pram.speed_lim_seg[i + 1]):
                if v[0][j] <= v[1][j]:
                    v[0][j] = v[1][j] = min(v[0][j], v[1][j])
                    v[0][j + 1:pram.speed_lim_seg[i + 1] - 1] = 0
                    v[1][pram.speed_lim_seg[i] + 1:j - 1] = 0

    mri = []
    for l, r, m in zip(v[0], v[1], v_lim):
        if l == r != 0:
            mri.append(min(l, r))
            continue
        if l == 0 and r == 0:
            mri.append(m / 3.6)
        elif l == 0:
            mri.append(r)
        else:
            mri.append(l)


    i = 0
    seg_t = np.zeros(len(pram.speed_lim_seg) - 1)
    for loc in range(len(mri)):
        loc += 1
        seg_t[i] += (2 * pram.train_step) / (mri[loc - 1] + mri[loc])
        if loc == pram.speed_lim_seg[i + 1]:
            i += 1
        if mri[loc] == 0:
            break

    return np.array(mri), sum(seg_t), seg_t, v_frontier


def get_psi_part_a(mri, sat_seg_t, mri_seg_t, v_frontier):

    psi = np.array(mri)
    is_done = False
    for seg in range(len(sat_seg_t)):
        if is_done:
            break
        if sat_seg_t[seg] == mri_seg_t[seg]:
            psi[pram.speed_lim_seg[seg]:pram.speed_lim_seg[seg + 1]] = mri[pram.speed_lim_seg[seg]:pram.speed_lim_seg[seg + 1]]
        else:
            low = pram.speed_lim_seg[seg]
            high = v_frontier[0][seg + 1]

            while True:
                time_start_loc = pram.speed_lim_seg[seg]
                time_start_seg = seg
                temp_psi = copy.deepcopy(np.array(psi))
                join_a = (low + high) // 2
                for i in range(seg+1, len(pram.speed_lim_seg)):
                    if temp_psi[join_a] >= temp_psi[pram.speed_lim_seg[i]]:
                        seg = i-1
                for join in range(v_frontier[1][seg], pram.speed_lim_seg[seg+1]):
                    if temp_psi[join] >= temp_psi[join_a] >= temp_psi[join + 1]:
                        join_b = join
                        temp_psi[join_a:join_b + 1] = temp_psi[join_a]
                        break
                t = 0
                for loc in range(time_start_loc, pram.speed_lim_seg[seg+1]+1):
                    if temp_psi[loc - 1] + temp_psi[loc] == 0:
                        raise Exception("v0+v1==0")
                    t += (2 * pram.train_step) / (temp_psi[loc - 1] + temp_psi[loc])
                if t > np.sum(sat_seg_t[time_start_seg:seg+1]):
                    low = join_a + 1
                else:
                    high = join_a - 1
                if low >= high:
                    psi = copy.deepcopy(temp_psi)
                    if seg == len(pram.speed_lim_seg)-2:
                        is_done = True
                    break
                seg = time_start_seg
    max_rate = np.max(np.array(mri))/np.max(psi)
    return psi, max_rate


def get_psi_part_b(psi, mri, v_frontier, sat_seg_t, rate):

    psi_rate = np.zeros(pram.line_len + 1)  # 初始化psi_rate数组
    for i, (psi_value, mri_value) in enumerate(zip(psi, mri)):
        if psi_value * rate >= mri_value:
            psi_rate[i] = mri_value
        else:
            psi_rate[i] = psi_value * rate
    low = v_frontier[0][2]
    high = pram.line_len
    convert = [0, 0]
    while True:
        coasting_loc = (low + high) // 2
        temp_psi = copy.deepcopy(psi_rate)
        is_renew = False
        for loc in range(coasting_loc, pram.line_len):
            loc += 1
            gear_action = 0
            slope_acc = get_slope_accelerated(loc)
            last_v = temp_psi[loc - 1]
            acc = get_accelerated(last_v, gear_action, slope_acc, loc)
            if last_v ** 2 + 2 * acc * pram.train_step < 0:
                now_v = 0
            else:
                now_v = math.sqrt(last_v ** 2 + 2 * acc * pram.train_step)
            if now_v == 0 and loc != pram.line_len:
                is_renew = True
                break
            temp_psi[loc] = now_v
            if temp_psi[loc] >= psi_rate[loc]:
                temp_psi[loc:] = psi_rate[loc:]
                if loc > pram.speed_lim_seg[-2]:
                    break
                '''
                else:
                    loc = pram.speed_lim_seg[-2]
                    continue
                '''
        if is_renew:
            low = coasting_loc + 1
            continue
        t = 0
        for loc in range(pram.speed_lim_seg[1], pram.line_len+1):
            if temp_psi[loc - 1] + temp_psi[loc] == 0:
                raise Exception("v0+v1==0")
            t += (2 * pram.train_step) / (temp_psi[loc - 1] + temp_psi[loc])
        convert = [coasting_loc, temp_psi[coasting_loc]]
        if convert[0] == pram.line_len-1:
            convert = [0, 0]
        if t > np.sum(sat_seg_t[1:]):
            low = coasting_loc + 1
        else:
            high = coasting_loc - 1
        if low >= high and pram.line_len <= 40000:
            psi_rate = copy.deepcopy(temp_psi)
            break
        if low + 10 >= high and pram.line_len > 40000:
            psi_rate = copy.deepcopy(temp_psi)
            break
    return psi_rate, convert


def get_line_step_time(line):
    ts = [0]
    t = 0
    for loc in range(1, len(line + 1)):
        if line[loc - 1] + line[loc] == 0:
            raise Exception("v0+v1==0")
        t += (2 * pram.train_step) / (line[loc - 1] + line[loc])
        ts.append(t)
    return ts


def get_line_step_energy(line):
    es = [0]
    e = 0
    for loc in range(len(line) - 1):
        loc += 1
        out_acc = (line[loc] ** 2 - line[loc - 1] ** 2) / (2 * pram.train_step)
        slope_acc = get_slope_accelerated(loc)
        last_v = line[loc - 1]
        non_gear_acc = get_accelerated(last_v, 0, slope_acc, loc)
        gear_acc = max(min(out_acc - non_gear_acc, pram.max_traction), pram.max_braking)
        if gear_acc > 0:
            # kwh
            e += (gear_acc * pram.train_weight * pram.train_step) / 3600
        es.append(e)

    return es


def get_line_time(line):

    t = 0
    for loc in range(1, len(line+1)):
        if line[loc - 1] + line[loc] == 0:
            raise Exception("v0+v1==0")
        t += (2 * pram.train_step) / (line[loc - 1] + line[loc])
    return t


def get_line_energy(line):

    e = 0
    for loc in range(len(line)-1):
        loc += 1
        out_acc = (line[loc]**2-line[loc-1]**2)/(2*pram.train_step)
        slope_acc = get_slope_accelerated(loc)
        last_v = line[loc - 1]
        non_gear_acc = get_accelerated(last_v, 0, slope_acc, loc)
        gear_acc = max(min(out_acc - non_gear_acc, pram.max_traction), pram.max_braking)
        if gear_acc > 0:
            e += (gear_acc * pram.train_weight * pram.train_step)/3600

    return e


def get_line_action(line):

    actions = [0]
    for loc in range(len(line) - 1):
        loc += 1
        out_acc = (line[loc] ** 2 - line[loc - 1] ** 2) / (2 * pram.train_step)
        slope_acc = get_slope_accelerated(loc)
        last_v = line[loc - 1]
        non_gear_acc = get_accelerated(last_v, 0, slope_acc, loc)

        if line[loc - 1] == 0:
            max_gear_action = pram.max_traction
        else:
            max_gear_action = min(pram.max_traction, pram.train_power / (pram.train_weight * line[loc - 1]))

        gear_acc = max(min(out_acc - non_gear_acc, max_gear_action), pram.max_braking)
        if gear_acc >= 0:
            action = gear_acc/max_gear_action
        else:
            action = gear_acc/pram.max_braking
        actions.append(action)
    return actions






def get_psi_min_energy(psi_a, mri, v_frontier, sat_seg_t, max_rate):

    rates = np.linspace(1, max_rate, 100)
    start = 0
    end = len(rates) - 1
    best_energy = get_line_energy(psi_a)
    best_energy_rate = rates[0]

    psi_b, _ = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rates[(start + end) // 2])
    energy = get_line_energy(psi_b)

    while start < end:
        mid = (start + end) // 2
        time = math.fabs(pram.plan_time - get_line_time(psi_b))

        psi_left, _ = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rates[(start + mid) // 2])
        energy_left = get_line_energy(psi_left)
        time_left = math.fabs(pram.plan_time - get_line_time(psi_left))

        psi_right, _ = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rates[(end + mid) // 2])
        energy_right = get_line_energy(psi_right)
        time_right = math.fabs(pram.plan_time - get_line_time(psi_right))

        if energy <= best_energy:
            best_energy = energy
            best_energy_rate = rates[mid]

        if max(time, time_left, time_right) >= 1 or energy_right >= energy_left:
            end = mid
            psi_b = psi_left
            energy = energy_left
            continue
        if energy_left > energy_right:
            start = mid
            psi_b = psi_right
            energy = energy_right
    return best_energy, best_energy_rate


def get_on_time_max_rate(psi_a, mri, v_frontier, sat_seg_t, max_rate):

    rates = np.linspace(1, max_rate, 100)
    left = 0
    right = len(rates) - 1

    while left < right:
        mid = (left + right) // 2
        psi_b, cnv = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rates[mid])
        time_error = math.fabs(pram.plan_time - get_line_time(psi_b))
        if time_error >= 1:
            right = mid
        else:
            left = mid + 1

    boundary = left
    return rates[boundary]


def get_bessel_curve(psi_a, mri, v_frontier, sat_seg_t, max_rate, energy_saving_rate, precision=100):

    rates = [1, (1+energy_saving_rate)/2, energy_saving_rate, (energy_saving_rate+max_rate)/2, max_rate]

    x = []
    y = []
    max_psi_b = psi_a
    min_psi_b = psi_a

    for rate in rates:
        psi_b, cnv = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rate)
        max_psi_b = np.maximum(max_psi_b, psi_b)
        min_psi_b = np.minimum(min_psi_b, psi_b)
        x.append(cnv[0])
        y.append(cnv[1])
    x = np.array(x)
    y = np.array(y)

    i = 0
    while True:
        if x[i] == x[i + 1] or x[i] == 0:
            x = np.delete(x, i)
            y = np.delete(y, i)
            i -= 1
        i += 1
        if i == len(x) - 1:
            break

    try:
        f = interp1d(x, y, kind='cubic')
    except:
        f = interp1d(x, y, kind='quadratic')
    # f = interp1d(x, y, kind='cubic')
    x = np.arange(np.min(x), np.max(x), 1)
    y = f(x)
    bessel = np.zeros(pram.line_len + 1)
    bessel[x] = y

    return np.maximum(max_psi_b, bessel), min_psi_b


def get_actions(psi_a, mri, v_frontier, sat_seg_t, max_rate, precision=100):
    rates = np.linspace(1, max_rate, precision)
    actions = []
    for rate in rates:
        psi_b, _ = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rate)
        actions.append(get_line_action(psi_b))
    actions = np.array(actions)
    return actions


def plot_line(psi_a, mri, v_frontier, sat_seg_t, max_rate, num=255):
    rates = np.linspace(1, max_rate, num)  # 在1到max_rate之间生成num个等间距的数
    colors = np.linspace(0x11, 0xff, num)  # 在0x11到0xff之间生成num个等间距的数
    for i in range(num):
        psi_b, cnv_b = get_psi_part_b(psi_a, mri, v_frontier, sat_seg_t, rates[i])  # 调用get_psi_part_b函数获取psi_b和cnv_b的值
        index = np.arange(0, pram.line_len + 1, 1)  # 在0到pram.line_len + 1之间生成步长为1的数列
        plt.plot(index, psi_b * 3.6, color='#50ef' + str(hex(int(colors[i])))[2:])  # 用生成的数值绘制线条，颜色使用十六进制表示


