import copy
from typing import Optional
import pygame
from pygame import gfxdraw
import gym
import math
from gym import spaces
import numpy as np
from gym.envs.tong.TTO import pram
import pandas as pd
from gym.envs.tong.TTO import ASTPSI
from gym.envs.tong.TTO import tong_utils as utils
import time
class trainEnv2(gym.Env):
    
    metadata = {
        "render_modes": ['human', 'rgb_array'],
        "render_fps": 60
    }

    
    def __init__(self):
        self.state = np.array([])
        self.easy_state = np.array([])
        self.info = np.array([])
        self.reward = 0
        self.location = 0
        
        self.plan_time = pram.plan_time
        
        self.line_len = pram.line_len
        
        self.train_type = pram.train_type
        
        self.train_len = pram.train_section_len * pram.train_type
        
        self.train_weight = pram.train_weight
        
        
        self.slope = pram.slope
        
        self.slope_seg = pram.slope_seg
        
        
        self.speed_lim = pram.speed_lim
        
        self.speed_lim_seg = pram.speed_lim_seg

        mri, min_t, min_seg_t, v_frontier = utils.get_mri()
        min_energy = 553.246997259125
        upper_bound_psi = mri
        lower_bound_psi = np.minimum(np.ones(pram.line_len+1)*10, mri)
        self.astpsi_energy_c = min_energy
        self.psi_ub = upper_bound_psi
        self.psi_lb = lower_bound_psi
        self.mri = mri

        
        self.speed = np.zeros(self.line_len + 1)
        
        self.slope = utils.get_list(self.slope, self.slope_seg, self.line_len)
        
        self.next_slope = utils.get_next_info(self.slope_seg, self.slope)
        
        self.next_slope_remain_step = utils.get_remain_step(self.slope_seg)
        
        self.speed_limit = utils.get_list(self.speed_lim, self.speed_lim_seg, self.line_len)
        
        self.next_speed_limit = utils.get_next_info(self.speed_lim_seg, self.speed_lim)
        
        self.next_speed_limit_remain_step = utils.get_remain_step(self.speed_lim_seg)
        
        self.remain_times = np.zeros(self.line_len + 1)
        self.remain_times[0] = self.plan_time
        
        self.remain_distances = np.zeros(self.line_len + 1)
        for index in range(0, self.line_len + 1):
            self.remain_distances[index] = self.line_len - index
        
        self.remain_energy = np.zeros(self.line_len + 1)
        self.remain_energy[0] = self.astpsi_energy_c




        
        self.speed_step = np.zeros(self.line_len + 1)
        self.km_speed_step = np.zeros(self.line_len + 1)
        
        self.gear_step = np.zeros(self.line_len + 1)
        
        self.time_step = np.zeros(self.line_len + 1)
        self.actual_times = np.zeros(self.line_len + 1)
        
        self.accelerated_step = np.zeros(self.line_len + 1)
        
        self.parking_accuracy = np.zeros(self.line_len + 1)
        
        self.energy = np.zeros((self.line_len + 1))
        self.acc_reward = np.zeros((self.line_len + 1))
        self.time_reward = np.zeros((self.line_len + 1))
        self.energy_reward = np.zeros((self.line_len + 1))
        self.over_steps = np.zeros((self.line_len + 1))
        self.low_steps = np.zeros((self.line_len + 1))
        self.gear_acc = np.zeros((self.line_len + 1))
        self.real_coasting = np.zeros((self.line_len + 1))

        
        self.min_gear_action = 0
        self.max_gear_action = 1

        self.low_action = np.array(
            [self.min_gear_action])
        self.high_action = np.array(
            [self.max_gear_action])

        self.over_psi_steps = 0
        self.low_psi_steps = 0
        
        self.min_speed = 0
        self.max_speed = max(pram.speed_lim)
        self.min_speed_limit = 0
        self.max_speed_limit = max(pram.speed_lim)
        self.min_next_speed_limit = 0
        self.max_next_speed_limit = max(pram.speed_lim)
        self.min_next_speed_limit_switch = 0
        self.max_next_speed_limit_switch = 20000
        self.min_current_slope = -100
        self.max_current_slope = 100
        self.min_next_slope = -100
        self.max_next_slope = 100
        self.min_next_slope_switch = 0
        self.max_next_slope_switch = 20000
        self.min_remaining_time = 0
        self.max_remaining_time = pram.plan_time+1
        self.min_remaining_distance = 0
        self._min_remaining_energy = -min_energy
        self._max_remaining_energy = min_energy
        self.max_remaining_distance = pram.line_len+1
        
        


        self.low_state = np.array(
            [self.min_speed, self.min_remaining_time, self.min_remaining_distance, self._min_remaining_energy])
        self.high_state = np.array(
            [self.max_speed, self.max_remaining_time, self.max_remaining_distance, self._max_remaining_energy])
        
        self.screen = None
        self.clock = None
        self.is_open = True
        self.surf = None
        self.height_y = utils.get_height()

        
        self.action_space = spaces.Box(low=self.low_action, high=self.high_action, shape=(1,), dtype=np.float32)

        
        self.observation_space = spaces.Box(low=self.low_state, high=self.high_state,
                                            dtype=np.float32)


        
        self.seed()
        
        self.reset()

    
    def seed(self, seed=None):
        pass

    
    
    
    def step(self, action):
        gear_action = 0
        if self.info[0][self.location] == 0:
            max_gear_action = pram.max_traction
        else:
            max_gear_action = min(pram.max_traction, pram.train_power / (
                        pram.train_mass_factor * pram.train_weight * self.info[0][self.location]))

        gear_action = max_gear_action * action
        if 5500 <= self.location <= 8000:
            gear_action = max_gear_action * action
        if 8000 < self.location <= 10200:
            gear_action = max_gear_action * action
        if 10200 < self.location < 30500:
            gear_action = max_gear_action * action



        origin_gear_action = gear_action

        is_done = False

        for train_step in range(pram.train_step):
            if is_done:
                break
            self.location += 1
            if self.psi_ub[self.location - 1] == self.psi_lb[self.location - 1] and self.location >= 34500:

                slope_accelerated = utils.get_slope_accelerated(self.location)
                last_speed = self.state[0][self.location - 1]

                speed = self.psi_ub[self.location]

                
                resist_acc = utils.get_accelerated(last_speed, 0, slope_accelerated, self.location)

                
                gear_action = max(min((speed ** 2 - last_speed ** 2) / (2 * pram.train_step) - resist_acc, max_gear_action), -1.2)
            
            else:

                
                if self.state[0][self.location - 1] >= self.psi_ub[self.location - 1]:

                    slope_accelerated = utils.get_slope_accelerated(self.location)
                    last_speed = self.state[0][self.location - 1]

                    speed = self.psi_ub[self.location]

                    
                    resist_acc = utils.get_accelerated(last_speed, 0, slope_accelerated, self.location)

                    
                    gear_action = max(min((speed ** 2 - last_speed ** 2) / (2 * pram.train_step) - resist_acc, max_gear_action), -1.5)

                    
                    if gear_action > origin_gear_action and self.location != 1:
                        gear_action = origin_gear_action

                    
                    if 8000 < self.location <= 17000:
                        gear_action = pram.min_action

                
                if self.state[0][self.location - 1] <= self.psi_lb[self.location - 1]:
                    slope_accelerated = utils.get_slope_accelerated(self.location)
                    last_speed = self.state[0][self.location - 1]

                    speed = self.psi_lb[self.location]

                    
                    resist_acc = utils.get_accelerated(last_speed, 0, slope_accelerated, self.location)

                    
                    gear_action = max(min((speed ** 2 - last_speed ** 2) / (2 * pram.train_step) - resist_acc, max_gear_action), -1)

                    
                    if gear_action < origin_gear_action:
                        gear_action = origin_gear_action

                    
                    if 8000 < self.location <= 17000:
                        gear_action = max_gear_action
            
            gear_accelerated = gear_action
            slope_accelerated = utils.get_slope_accelerated(self.location)
            last_speed = self.info[0][self.location - 1]
            
            accelerated = utils.get_accelerated(last_speed, gear_accelerated, slope_accelerated, self.location)
            
            speed = max(utils.get_speed(last_speed, accelerated, self.location), 0)

            
            move_time = utils.get_move_time(speed, last_speed, accelerated)
            
            accuracy = -1
            
            energy = utils.get_energy(gear_accelerated)
            
            
            remain_times = self.state[7][self.location - 1] - move_time
            
            actual_times = self.info[4][self.location - 1] + move_time
            
            actual_energy = self.info[7][self.location - 1] + energy



            remain_energy = self.easy_state[3][self.location - 1] - energy
            
            
            done = bool(self.location == self.line_len)
            is_done = done

            self.state[0][self.location] = speed
            self.state[7][self.location] = remain_times


            self.easy_state[0][self.location] = speed
            self.easy_state[1][self.location] = remain_times
            self.easy_state[3][self.location] = remain_energy
            

            self.info[0][self.location] = speed
            self.info[1][self.location] = speed * 3.6
            self.info[2][self.location] = gear_action
            self.info[3][self.location] = move_time
            self.info[4][self.location] = actual_times
            self.info[5][self.location] = accelerated
            if done:
                if speed == 0:
                    
                    accuracy = math.fabs(self.line_len - ((self.location - 1) + (last_speed ** 2) / (-2 * accelerated)))
                else:
                    accuracy = speed * speed / (-2 * accelerated)

            self.info[6][self.location] = accuracy
            self.info[7][self.location] = actual_energy

            self.reward = 0

            if done:
                print("energy:",self.info[7][self.location])
                
                
                if math.fabs(self.info[6][self.location]) <= 5:
                    acc_reward = 0
                else:
                    
                    acc_reward = - self.info[6][self.location]
                self.reward += acc_reward
                self.info[10][self.location] = acc_reward
                
                

                time_reward = 3 - 630 * math.fabs(self.plan_time - self.info[4][self.location]) / self.plan_time

                self.reward += time_reward
                self.info[11][self.location] = time_reward

                
                
                
                if self.info[7][self.location] >= self.astpsi_energy_c:
                    energy_reward = -3 + 180 * (self.astpsi_energy_c - self.info[7][self.location]) / self.astpsi_energy_c
                else:
                    energy_reward = min(
                        180 * (self.astpsi_energy_c - self.info[7][self.location]) / self.astpsi_energy_c, 8)

                self.reward += energy_reward
                self.info[12][self.location] = energy_reward

                self.info[13][self.location] = self.over_psi_steps
                self.info[14][self.location] = self.low_psi_steps

                print("\nR:", self.reward, " 精确:", acc_reward, " 准时", time_reward, " 节能:", energy_reward)

            else:

                if speed * 3.6 == self.info[8][self.location] and last_speed != 0 and origin_gear_action > gear_action:
                    if self.location < self.line_len - 10:
                        self.over_psi_steps += 1
                        
                        
                if speed * 3.6 == self.info[9][self.location] and last_speed != 0 and origin_gear_action < gear_action:
                    if self.location < self.line_len - 10:
                        self.low_psi_steps += 1
                        
                        

        self.info[15][self.location] = gear_action


        reward = self.reward
        state = np.array([index[self.location] for index in self.easy_state], dtype=np.float32)
        info = np.array([index[self.location] for index in self.info], dtype=np.float32)

        return state, reward, is_done, is_done, info

    def reset(
            self,
            *,
            seed: Optional[int] = None,
            return_info: bool = False,
            options: Optional[dict] = None
    ):
        super().reset(seed=seed)

        self.location = 0
        self.reward = 0

        self.over_psi_steps = 0
        self.low_psi_steps = 0

        self.speed = np.zeros(self.line_len + 1)
        self.remain_times = np.zeros(self.line_len + 1)
        self.remain_times[0] = self.plan_time
        self.remain_energy = np.zeros(self.line_len + 1)
        self.remain_energy[0] = self.astpsi_energy_c
        self.psi_time_shift = np.zeros(self.line_len + 1)
        

        
        self.state = np.array([
            np.array(self.speed),
            np.array(self.speed_limit),
            np.array(self.next_speed_limit),
            np.array(self.next_speed_limit_remain_step),
            np.array(self.slope),
            np.array(self.next_slope),
            np.array(self.next_slope_remain_step),
            np.array(self.remain_times),
            np.array(self.remain_distances)
        ])
        self.easy_state = np.array([
            np.array(self.speed),
            np.array(self.remain_times),
            np.array(self.remain_distances),
            np.array(self.remain_energy),
        ])
        self.speed_step = np.zeros(self.line_len + 1)
        self.km_speed_step = np.zeros(self.line_len + 1)
        self.gear_step = np.zeros(self.line_len + 1)
        self.time_step = np.zeros(self.line_len + 1)
        self.actual_times = np.zeros(self.line_len + 1)
        self.accelerated_step = np.zeros(self.line_len + 1)
        self.parking_accuracy = np.zeros(self.line_len + 1)
        self.energy = np.zeros((self.line_len + 1))
        self.acc_reward = np.zeros((self.line_len + 1))
        self.time_reward = np.zeros((self.line_len + 1))
        self.energy_reward = np.zeros((self.line_len + 1))
        self.over_steps = np.zeros((self.line_len + 1))
        self.low_steps = np.zeros((self.line_len + 1))
        self.gear_acc = np.zeros((self.line_len + 1))
        self.info = np.array([
            
            np.array(self.speed_step),
            
            np.array(self.km_speed_step),
            
            np.array(self.gear_step),
            
            np.array(self.time_step),
            
            np.array(self.actual_times),
            
            np.array(self.accelerated_step),
            
            np.array(self.parking_accuracy),
            
            np.array(self.energy),
            
            np.array(self.psi_ub),
            
            np.array(self.psi_lb),
            
            np.array(self.acc_reward),
            
            np.array(self.time_reward),
            
            np.array(self.energy_reward),
            
            np.array(self.over_steps),
            
            np.array(self.low_steps),
            
            np.array(self.gear_acc),

        ])
        return np.array([index[0] for index in self.easy_state], dtype=np.float32)

    

    def render(self, mode='human'):
        screen_w = pram.screen_width
        screen_h = pram.screen_height

        shift_scale_y = screen_h * 0.25
        multiple_scale_y = 1
        shift_scale_x = 12
        multiple_scale_x = 0.98

        if self.screen is None:
            pygame.init()
            self.screen = pygame.display.set_mode((screen_w, screen_h))
        if self.clock is None:
            self.clock = pygame.time.Clock()

        self.surf = pygame.Surface((screen_w, screen_h))
        self.surf.fill((255, 255, 255))

        v_limit = utils.get_py_draw_line(self.state[8][self.line_len::-1], self.state[1]
                                         , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=v_limit, closed=False, color=(100, 0, 0))

        mri = utils.get_py_draw_line(self.state[8][self.line_len::-1], self.mri*3.6
                                     , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=mri, closed=False, color=(255, 0, 0))

        psi_ub = utils.get_py_draw_line(self.state[8][self.line_len::-1], self.psi_ub*3.6
                                        , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=psi_ub, closed=False, color='orange')

        psi_lb = utils.get_py_draw_line(self.state[8][self.line_len::-1], self.psi_lb*3.6
                                        , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=psi_lb, closed=False, color=(88, 142, 85))



        x_axis = utils.get_py_draw_line(self.state[8][self.line_len::-1], np.repeat(0.25, self.line_len)
                                        , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=x_axis, closed=False, color=(0, 0, 0))

        y_axis = utils.get_py_draw_line(np.array([0, 0]), np.array([0, max(self.speed_limit)])
                                        , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=y_axis, closed=False, color=(0, 0, 0))


        if max(self.speed_limit) > 100:
            scale_num = max(self.speed_limit) // 25
            scale_rate = 25
        else:
            scale_num = (max(self.speed_limit) // 10)+1
            scale_rate = 10
        for scale_i in range(1, int(scale_num)):
            y_axis_scale = utils.get_py_draw_line(np.array([0, 20]), np.array([scale_rate*scale_i, scale_rate*scale_i])
                                                  , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
            pygame.draw.aalines(self.surf, points=y_axis_scale, closed=False, color=(0, 0, 0))

        slope = utils.get_py_draw_line(self.state[8][self.line_len::-1], self.height_y
                                       , x_rate=0.98, y_rate=0.13, x_shift=0.01, y_shift=0.05)
        pygame.draw.aalines(self.surf, points=slope, closed=False, color=(0, 0, 255))


        
        loc = self.location

        gfxdraw.filled_circle(self.surf, int(((loc * 0.98) * pram.x_zoom + 0.01*screen_w)),
                              int(((self.height_y[loc] * 0.13) * pram.y_zoom + 0.05*screen_h)), 2, (255, 0, 0))

        if self.line_len != loc:
            loc_xs = self.state[8][self.line_len:self.line_len - loc - 1:-1]
            gear_xs = self.state[8][self.line_len:self.line_len - loc - 1:-1]
        else:
            loc_xs = self.state[8][self.line_len::-1]
            gear_xs = self.state[8][self.line_len::-1]

        loc_ = utils.get_py_draw_line(loc_xs, self.state[0][0:loc + 1] * 3.6
                                      , x_rate=0.98, y_rate=0.5, x_shift=0.01, y_shift=0.25)
        pygame.draw.aalines(self.surf, points=loc_, closed=False, color=(0, 0, 0))

        gear_zero = utils.get_py_draw_line(np.array([0, self.line_len]), np.array([0, 0])
                                           , x_rate=0.98, y_rate=1, x_shift=0.01, y_shift=0.15)
        pygame.draw.aalines(self.surf, points=gear_zero, closed=False, color=(0, 0, 0))

        
        
        

        gear = utils.get_py_draw_line(gear_xs, self.info[2][0:loc + 1]
                                      , x_rate=0.98, y_rate=7, x_shift=0.01, y_shift=0.15)
        pygame.draw.aalines(self.surf, points=gear, closed=False, color=(0, 0, 255))

        self.surf = pygame.transform.flip(self.surf, False, True)
        self.screen.blit(self.surf, (0, 0))

        my_font = pygame.font.SysFont("pingfang", 16)

        state_name = ["速度km/h", "当前限速", "下一限速", "转换距离", "当前坡度‰", "下一坡度", "转换距离", "剩余时间s",
                      "剩余距离m"]
        for state_name_i in range(len(state_name)):
            text = state_name[state_name_i]
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (0 + 77 * state_name_i , 5))

        for state_i in range(len(self.state)):
            text = str(round(self.state[state_i][loc], 2))
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (0 + 77 * state_i , 30))

        info_name = ["速度m/s", "速度km/s", "档位m/s^2", "位移时间s", "总时间s", "加速度", "准确性m", "能耗kJ"]
        for info_name_i in range(len(info_name)):
            text = info_name[info_name_i]
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (77 * info_name_i, 55))

        for info_i in range(len(info_name)):
            text = str(round(self.info[info_i][loc], 2))
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (0 + 77 * info_i, 80))

        text = "奖励"
        textImage = my_font.render(text, True, (0, 0, 0))
        self.screen.blit(textImage, (0 + 77 * 6, 105))

        all_reward = str(round(self.info[10][loc] + self.info[11][loc] + self.info[12][loc], 4))
        textImage = my_font.render(all_reward, True, (0, 0, 0))
        self.screen.blit(textImage, (77 * 6, 130))

        info_name = ["精确奖励", "准时奖励", "节能奖励", "精确贡献", "准时贡献", "节能贡献"]
        for info_name_i in range(len(info_name)):
            text = info_name[info_name_i]
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (0 + 77 * info_name_i, 105))

        info_list = [0, 0, 0]
        for info_i in range(3):
            text = str(round(self.info[10 + info_i][loc], 2))
            info_list[info_i] = math.fabs(self.info[10 + info_i][loc])
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (77 * info_i, 130))

        for info_i in range(3, 6):
            if info_list[info_i - 3] != 0:
                text = str(round((info_list[info_i - 3] * 100) / (info_list[0] + info_list[1] + info_list[2]), 2)) + '%'
            else:
                text = str(0)
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (77 * info_i, 130))

        psi_info_name = ["超速次数", "低速次数"]
        for psi_info_name_i in range(len(psi_info_name)):
            text = psi_info_name[psi_info_name_i]
            textImage = my_font.render(text, True, (0, 0, 0))
            self.screen.blit(textImage, (77 * (psi_info_name_i + 7), 105))

        over_psi_steps = str(round(self.over_psi_steps, 0))
        textImage = my_font.render(over_psi_steps, True, (0, 0, 0))
        self.screen.blit(textImage, (77 * 7, 130))

        low_psi_steps = str(round(self.low_psi_steps, 0))
        textImage = my_font.render(low_psi_steps, True, (0, 0, 0))
        self.screen.blit(textImage, (77 * 8, 130))

        if mode == "human":
            self.clock.tick(self.metadata["render_fps"])
            pygame.display.flip()

        done = bool(loc == self.line_len)
        if done:
            pygame.time.wait(1000)

        if mode == "rgb_array":
            return np.transpose(
                np.array(pygame.surfarray.pixels3d(self.screen)), axes=(1, 0, 2)
            )
        else:
            return self.is_open

    def close(self):
        if self.screen is not None:
            pygame.quit()
            self.is_open = False


if __name__ == '__main__':
    train_env = trainEnv1()


    pd.set_option('expand_frame_repr', False)
    pd.set_option('colheader_justify', 'left')
    state1, reward1, done1, info1 = 0, 0, 0, 0
    v_step = []
    loc_step = []
    t_step = []
    e_step = []


    for i in range(100):
        done2 = False

        steps = int(input("输入步数"))
        action = float(input("输入档位"))

        i = 0
        for step in range(steps):
            i += 1
            state1, reward1, done1,done1, info1 = train_env.step(action)

            train_env.render(mode="human")
            if done1:
                done2 = True
                break

        
        
        
        
        
        
        
        
        
        if done2:
            break
