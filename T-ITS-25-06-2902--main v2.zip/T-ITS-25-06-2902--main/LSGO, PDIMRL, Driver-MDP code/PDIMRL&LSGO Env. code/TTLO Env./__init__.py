from gym.envs.registration import load_env_plugins as _load_env_plugins
from gym.envs.registration import make, register, registry, spec

# Hook to load plugins from entry points
_load_env_plugins()




register(
    id="LSGO-v0",
    entry_point="gym.envs.LSGO:trainEnv",
    max_episode_steps=100000,
    reward_threshold=200.0,
)

